import { useState } from "react";
import { motion } from "framer-motion";

export default function App() {
  const [form, setForm] = useState({
    name: "",
    phone: "",
    city: "",
    income: "",
    car: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  return (
    <div style={{ background: "black", color: "white", minHeight: "100vh", padding: 20 }}>

      <h1 style={{ color: "gold" }}>Auto Finance Hub.pk</h1>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <h2>Drive Your Dream Car</h2>
        <p>Easy Finance • Fast Approval • WhatsApp Support</p>
      </motion.div>

      <div style={{ marginTop: 20 }}>
        <input name="name" placeholder="Name" onChange={handleChange} /><br/><br/>
        <input name="phone" placeholder="Phone" onChange={handleChange} /><br/><br/>
        <input name="city" placeholder="City" onChange={handleChange} /><br/><br/>
        <input name="income" placeholder="Income" onChange={handleChange} /><br/><br/>
        <input name="car" placeholder="Car Model" onChange={handleChange} /><br/><br/>

        <button style={{ background: "gold", padding: 10 }}>Submit</button>
      </div>

      <div style={{ marginTop: 40 }}>
        <a href="https://wa.me/923074182085" target="_blank">
          WhatsApp Support
        </a>
      </div>
    </div>
  );
}
